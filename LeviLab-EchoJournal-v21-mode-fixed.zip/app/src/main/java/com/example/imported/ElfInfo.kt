package com.example.imported

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Small read-only ELF64 reader used only to log how the game's native libraries depend on each other. */
object ElfInfo {

    private val interesting = setOf(
        "malloc", "free", "calloc", "realloc", "memalign", "posix_memalign", "aligned_alloc",
        "malloc_usable_size", "_Znwm", "_Znam", "_ZdlPv", "_ZdaPv", "_ZdlPvm", "_ZdaPvm"
    )

    private class Sec(val type: Int, val offset: Long, val size: Long, val link: Int)

    private fun cstr(bytes: ByteArray, off: Int): String {
        if (off < 0 || off >= bytes.size) return ""
        var e = off
        while (e < bytes.size && bytes[e] != 0.toByte()) e++
        return String(bytes, off, e - off, Charsets.UTF_8)
    }

    fun describe(file: File): String {
        return try {
            RandomAccessFile(file, "r").use { raf ->
                val hdr = ByteArray(64)
                raf.readFully(hdr)
                if (hdr[0] != 0x7f.toByte() || hdr[1] != 'E'.code.toByte() || hdr[4] != 2.toByte()) {
                    return "not ELF64"
                }
                val bb = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN)
                val shoff = bb.getLong(0x28)
                val shentsize = bb.getShort(0x3A).toInt() and 0xffff
                val shnum = bb.getShort(0x3C).toInt() and 0xffff
                if (shoff <= 0L || shnum == 0 || shentsize < 64) return "no section headers"

                val secs = ArrayList<Sec>()
                for (i in 0 until shnum) {
                    val b = ByteArray(shentsize)
                    raf.seek(shoff + i.toLong() * shentsize)
                    raf.readFully(b)
                    val s = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
                    secs.add(Sec(s.getInt(4), s.getLong(0x18), s.getLong(0x20), s.getInt(0x28)))
                }

                fun readSec(s: Sec): ByteArray {
                    if (s.size <= 0L || s.size > 64L * 1024 * 1024) return ByteArray(0)
                    val data = ByteArray(s.size.toInt())
                    raf.seek(s.offset)
                    raf.readFully(data)
                    return data
                }

                val needed = ArrayList<String>()
                var soname = ""
                val dyn = secs.firstOrNull { it.type == 6 }
                if (dyn != null && dyn.link in secs.indices) {
                    val str = readSec(secs[dyn.link])
                    val d = ByteBuffer.wrap(readSec(dyn)).order(ByteOrder.LITTLE_ENDIAN)
                    var p = 0
                    while (p + 16 <= d.capacity()) {
                        val tag = d.getLong(p)
                        val v = d.getLong(p + 8)
                        if (tag == 0L) break
                        if (tag == 1L) needed.add(cstr(str, v.toInt()))
                        if (tag == 14L) soname = cstr(str, v.toInt())
                        p += 16
                    }
                }

                val defines = ArrayList<String>()
                val imports = ArrayList<String>()
                val sym = secs.firstOrNull { it.type == 11 }
                if (sym != null && sym.link in secs.indices) {
                    val str = readSec(secs[sym.link])
                    val sb = ByteBuffer.wrap(readSec(sym)).order(ByteOrder.LITTLE_ENDIAN)
                    var p = 0
                    while (p + 24 <= sb.capacity()) {
                        val nameOff = sb.getInt(p)
                        val shndx = sb.getShort(p + 6).toInt() and 0xffff
                        val name = cstr(str, nameOff)
                        if (name in interesting) {
                            if (shndx == 0) imports.add(name) else defines.add(name)
                        }
                        p += 24
                    }
                }
                "soname=$soname needed=$needed defines=$defines imports=$imports"
            }
        } catch (t: Throwable) {
            "error ${t.javaClass.simpleName}: ${t.message}"
        }
    }
}
