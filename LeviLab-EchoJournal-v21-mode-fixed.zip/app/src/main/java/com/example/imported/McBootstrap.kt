package com.example.imported

import android.app.Activity
import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.content.res.AssetManager
import android.content.res.Resources
import android.os.Build
import android.os.Bundle
import android.view.ContextThemeWrapper
import dalvik.system.PathClassLoader
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Runs only inside the dedicated ":mc" process. It makes the imported APK's
 * code, native libraries and assets visible to this process so that
 * com.mojang.minecraftpe.MainActivity (declared in our manifest) can start.
 */
object McBootstrap {

    /** Stops a running game process so a newly selected version loads cleanly. */
    fun killGameProcess(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.runningAppProcesses.orEmpty().forEach {
                if (it.processName.endsWith(":mc")) {
                    log(context, "Stopping old game process pid=${it.pid}")
                    android.os.Process.killProcess(it.pid)
                }
            }
        } catch (t: Throwable) {
            log(context, "killGameProcess failed: ${t.message}")
        }
    }

    fun isMcProcess(): Boolean {
        return try {
            File("/proc/self/cmdline").readText().substringBefore('\u0000').endsWith(":mc")
        } catch (t: Throwable) {
            false
        }
    }

    fun log(context: Context, message: String) {
        try {
            val f = ImportedApkStore.runtimeLogFile(context)
            f.parentFile?.mkdirs()
            if (f.exists() && f.length() > 512 * 1024) f.delete()
            val ts = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            f.appendText("[$ts] $message\n")
        } catch (e: Throwable) {
        }
    }

    /** Writes any uncaught Java exception from the :mc process into the app log. */
    private fun installCrashLogger(context: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                log(context, "UNCAUGHT in thread ${thread.name}: ${throwable.javaClass.name}: ${throwable.message}")
                log(context, throwable.stackTraceToString().take(3000))
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    private fun exemptHiddenApis(context: Context) {
        if (Build.VERSION.SDK_INT < 28) return
        try {
            org.lsposed.hiddenapibypass.HiddenApiBypass.addHiddenApiExemptions("L")
            log(context, "Hidden API exemptions: OK")
        } catch (t: Throwable) {
            log(context, "Hidden API exemptions failed: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun modeFile(context: Context) = File(ImportedApkStore.rootDir(context), "mode.txt")

    /** 1 = merge into the app class loader and preload libs (original way); 2 = separate game class loader. */
    fun loadMode(context: Context): Int = try {
        modeFile(context).readText().trim().toInt()
    } catch (t: Throwable) {
        1
    }

    fun setLoadMode(context: Context, mode: Int) {
        try {
            ImportedApkStore.rootDir(context).mkdirs()
            modeFile(context).writeText(mode.toString())
        } catch (_: Throwable) {
        }
    }

    /** Logs (once per imported version) how the game's native libraries depend on each other. */
    fun logElfDiagnostics(context: Context) {
        try {
            val id = ImportedApkStore.activeId(context) ?: return
            val marker = File(ImportedApkStore.rootDir(context), "elf_$id.done")
            if (marker.exists()) return
            val libDir = ImportedApkStore.libDir(context)
            libDir.listFiles { f -> f.isFile && f.name.endsWith(".so") }
                ?.sortedBy { it.name }
                ?.forEach { log(context, "ELF ${it.name}: ${ElfInfo.describe(it)}") }
            marker.writeText("1")
        } catch (t: Throwable) {
            log(context, "ELF diagnostics failed: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    @Volatile
    private var gameLoader: ClassLoader? = null

    /** Looks inside the game's dex first (for non-framework classes) and owns its own native namespace. */
    private class GameClassLoader(dex: String, lib: String, parent: ClassLoader) : PathClassLoader(dex, lib, parent) {
        override fun loadClass(name: String, resolve: Boolean): Class<*> {
            // Android's ClassLoader API does not expose getClassLoadingLock on all
            // supported toolchains. Use this loader's monitor as a compatible,
            // re-entrant lock while preserving the normal load/resolve behavior.
            synchronized(this) {
                val loaded = findLoadedClass(name)
                if (loaded != null) return loaded

                val framework = name.startsWith("java.") || name.startsWith("javax.") ||
                    name.startsWith("android.") || name.startsWith("dalvik.") ||
                    name.startsWith("libcore.") || name.startsWith("sun.")

                if (!framework) {
                    try {
                        val gameClass = findClass(name)
                        if (resolve) resolveClass(gameClass)
                        return gameClass
                    } catch (_: ClassNotFoundException) {
                        // Fall back to the parent/framework class loader below.
                    }
                }

                return super.loadClass(name, resolve)
            }
        }
    }

    private fun findField(obj: Any, name: String): java.lang.reflect.Field {
        var c: Class<*>? = obj.javaClass
        while (c != null) {
            try {
                val f = c.getDeclaredField(name)
                f.isAccessible = true
                return f
            } catch (_: NoSuchFieldException) {
                c = c.superclass
            }
        }
        throw NoSuchFieldException(name)
    }

    /** Mode 2: the game gets its own class loader (and therefore its own linker namespace for its libs). */
    private fun installSeparateLoader(base: Context, apk: File, libDir: File, info: ImportedApkInfo) {
        val appLoader = base.classLoader
        val loader = GameClassLoader(apk.absolutePath, libDir.absolutePath, appLoader)
        gameLoader = loader
        var ctx: Context = base
        while (ctx is android.content.ContextWrapper && ctx.javaClass.name != "android.app.ContextImpl") {
            ctx = ctx.baseContext ?: break
        }
        val pkgInfo = findField(ctx, "mPackageInfo").get(ctx)!!
        findField(pkgInfo, "mClassLoader").set(pkgInfo, loader)
        Thread.currentThread().contextClassLoader = loader
        log(base, "Mode 2: game class loader installed as the app class loader")
        val cls = Class.forName(info.mainActivity, false, loader)
        log(base, "Mode 2: ${cls.name} defined by game loader = ${cls.classLoader === loader}")
    }

    /** Mode 2: loads only libMCPELIFE through the game loader; everything else resolves on its own. */
    private fun preloadMode2(app: Application) {
        val loader = gameLoader ?: run {
            log(app, "Mode 2: game loader missing")
            return
        }
        try {
            val hidden = Class.forName("MCPELIFE0.hidden.Hidden0", false, loader)
            val m = Runtime::class.java.getDeclaredMethod(
                "loadLibrary0", ClassLoader::class.java, Class::class.java, String::class.java
            )
            m.isAccessible = true
            log(app, "Mode 2: loading MCPELIFE through the game loader ...")
            m.invoke(Runtime.getRuntime(), loader, hidden, "MCPELIFE")
            log(app, "Mode 2: MCPELIFE loaded")
        } catch (t: Throwable) {
            val c = (t as? java.lang.reflect.InvocationTargetException)?.targetException ?: t
            log(app, "Mode 2: MCPELIFE load failed: ${c.javaClass.simpleName}: ${c.message}")
        }
    }

    /** Called from Application.attachBaseContext in the ":mc" process. */
    fun install(base: Context) {
        log(base, "=== :mc process starting (SDK ${Build.VERSION.SDK_INT}, ${Build.MODEL}) ===")
        installCrashLogger(base)
        val info = ImportedApkStore.readInfo(base)
        if (info == null) {
            log(base, "ERROR: no imported APK found. Import one first.")
            return
        }
        val apk = ImportedApkStore.apkFile(base)
        val libDir = ImportedApkStore.libDir(base)
        log(base, "APK: ${info.packageName} v${info.versionName} (${info.versionCode}), ${apk.length() / (1024 * 1024)} MB")

        exemptHiddenApis(base)

        if (loadMode(base) == 2) {
            log(base, "Load mode = 2 (separate game class loader)")
            try {
                installSeparateLoader(base, apk, libDir, info)
            } catch (t: Throwable) {
                log(base, "Mode 2 install failed: ${t.javaClass.simpleName}: ${t.message}")
            }
            return
        }
        log(base, "Load mode = 1 (merged class loader + preload)")

        try {
            val appLoader = base.classLoader
            val pluginLoader = PathClassLoader(apk.absolutePath, libDir.absolutePath, null)

            val bdc = Class.forName("dalvik.system.BaseDexClassLoader")
            val pathListField = bdc.getDeclaredField("pathList")
            pathListField.isAccessible = true
            val appList = pathListField.get(appLoader)!!
            val pluginList = pathListField.get(pluginLoader)!!

            mergeArrayField(appList, pluginList, "dexElements")
            log(base, "Merged dex elements (plugin first)")

            runCatching {
                mergeArrayField(appList, pluginList, "nativeLibraryPathElements")
                log(base, "Merged nativeLibraryPathElements")
            }.onFailure {
                log(base, "nativeLibraryPathElements merge failed: ${it.javaClass.simpleName}: ${it.message}")
            }

            runCatching {
                val f = appList.javaClass.getDeclaredField("nativeLibraryDirectories")
                f.isAccessible = true
                @Suppress("UNCHECKED_CAST")
                val cur = f.get(appList) as List<File>
                f.set(appList, listOf(libDir) + cur)
                log(base, "Added native lib dir: ${libDir.absolutePath}")
            }.onFailure {
                log(base, "nativeLibraryDirectories update failed: ${it.javaClass.simpleName}: ${it.message}")
            }

            try {
                val cls = appLoader.loadClass(info.mainActivity)
                log(base, "OK: class visible -> ${cls.name} (super=${cls.superclass?.name})")
            } catch (t: Throwable) {
                log(base, "ERROR: cannot load ${info.mainActivity}: ${t.javaClass.simpleName}: ${t.message}")
            }
        } catch (t: Throwable) {
            log(base, "ERROR during injection: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    /**
     * Loads every bundled .so by absolute path before the game starts, retrying
     * until no more progress is made. This lets dependencies such as
     * libMallocRedirect.so resolve even though the linker namespace was created
     * before we added the imported lib folder.
     */
    /** Called from Application.onCreate (the app context is ready there, not in attachBaseContext). */
    fun preloadFromOnCreate(app: Application) {
        if (loadMode(app) == 2) {
            preloadMode2(app)
            return
        }
        try {
            preloadNativeLibs(app, ImportedApkStore.libDir(app))
        } catch (t: Throwable) {
            log(app, "Preload error: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    /**
     * Android 11+ keeps the exit record of the game process, including the native
     * tombstone for crashes. Reads it from the app's own process, so no bug report is needed.
     */
    fun logLastGameExit(context: Context) {
        if (Build.VERSION.SDK_INT < 30) return
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val exits = am.getHistoricalProcessExitReasons(context.packageName, 0, 5)
            val last = exits.firstOrNull { it.processName.endsWith(":mc") }
            if (last == null) {
                log(context, "LAST EXIT: no record for :mc yet")
                return
            }
            val marker = "time=${last.timestamp}"
            val existing = try { ImportedApkStore.runtimeLogFile(context).readText() } catch (t: Throwable) { "" }
            if (existing.contains(marker)) return // already recorded; keeps the refresh button idempotent
            log(context, "LAST EXIT: reason=${last.reason} status=${last.status} $marker desc=${last.description}")
            last.traceInputStream?.use { ins ->
                val raw = ins.bufferedReader().readText()
                // Keep only readable ASCII so the log view is not filled with binary bytes
                val clean = buildString {
                    for (c in raw) if (c == '\n' || c == '\t' || c in ' '..'~') append(c) else if (c == '\u0000') continue
                }
                traceFile(context).writeText(clean.take(60000))
                val keys = listOf("signal", "Abort", "Fatal", "Exception", "Cause", "pc ", "#00", "#01", "UNCAUGHT", "backtrace", "ANR", "Reason")
                val useful = clean.lines().filter { line -> keys.any { line.contains(it, ignoreCase = true) } }.take(25)
                log(context, "TRACE saved (${clean.length} chars) in last_trace.txt")
                useful.forEach { log(context, "  " + it.take(200)) }
            }
        } catch (t: Throwable) {
            log(context, "exit info failed: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    fun traceFile(context: Context): File = File(ImportedApkStore.runtimeLogFile(context).parentFile, "last_trace.txt")

    /** libc++ first, then MallocRedirect (it must be in place before other code allocates), then the rest. */
    private fun priorityOf(name: String): Int = when (name) {
        "libc++_shared.so" -> 0
        "libMallocRedirect.so" -> 1
        else -> 2
    }

    private fun preloadNativeLibs(context: Context, libDir: File) {
        val pending = libDir.listFiles { f -> f.isFile && f.name.endsWith(".so") && f.name != "libminecraftpe.so" }
            ?.sortedWith(compareBy({ priorityOf(it.name) }, { it.name }))
            ?.toMutableList() ?: return
        val lastError = mutableMapOf<String, String>()
        var progress = true
        while (pending.isNotEmpty() && progress) {
            progress = false
            val iter = pending.iterator()
            while (iter.hasNext()) {
                val lib = iter.next()
                try {
                    // Logged BEFORE loading, so if the process dies natively the last line names the culprit
                    log(context, "Loading ${lib.name} ...")
                    // Use the canonical path (the linker records libraries by this form), so no library is loaded twice
                    System.load(lib.canonicalPath)
                    log(context, "Preloaded ${lib.name}")
                    iter.remove()
                    progress = true
                } catch (t: Throwable) {
                    lastError[lib.name] = "${t.javaClass.simpleName}: ${t.message}"
                }
            }
        }
        pending.forEach { log(context, "Preload failed: ${it.name} -> ${lastError[it.name]}") }
    }

    private fun mergeArrayField(target: Any, source: Any, name: String) {
        val f = target.javaClass.getDeclaredField(name)
        f.isAccessible = true
        val a = f.get(target) as Array<*>
        val b = f.get(source) as Array<*>
        val comp = a.javaClass.componentType ?: error("no component type for $name")
        @Suppress("UNCHECKED_CAST")
        val merged = java.lang.reflect.Array.newInstance(comp, a.size + b.size) as Array<Any?>
        System.arraycopy(b, 0, merged, 0, b.size)
        System.arraycopy(a, 0, merged, b.size, a.size)
        f.set(target, merged)
    }

    /** Swaps the activity's resources/assets for the imported APK's and applies its theme. */
    fun prepareActivity(activity: Activity) {
        val info = ImportedApkStore.readInfo(activity) ?: return
        try {
            val apk = ImportedApkStore.apkFile(activity)
            val am = AssetManager::class.java.getDeclaredConstructor().newInstance()
            val add = AssetManager::class.java.getMethod("addAssetPath", String::class.java)
            val cookie = add.invoke(am, apk.absolutePath) as? Int ?: 0
            log(activity, "AssetManager.addAssetPath cookie=$cookie")

            val cur = activity.resources
            @Suppress("DEPRECATION")
            val res = Resources(am, cur.displayMetrics, cur.configuration)
            val f = ContextThemeWrapper::class.java.getDeclaredField("mResources")
            f.isAccessible = true
            f.set(activity, res)
            if (info.themeResId != 0) activity.setTheme(info.themeResId)
            log(activity, "Resources swapped (theme=0x${Integer.toHexString(info.themeResId)})")
        } catch (t: Throwable) {
            log(activity, "ERROR swapping resources: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    fun registerHooks(app: Application) {
        log(app, "Application.onCreate in :mc")
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityPreCreated(activity: Activity, savedInstanceState: Bundle?) {
                log(activity, "PreCreated: ${activity.javaClass.name}")
                prepareActivity(activity)
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                if (Build.VERSION.SDK_INT < 29) prepareActivity(activity)
            }

            override fun onActivityStarted(activity: Activity) {}
            override fun onActivityResumed(activity: Activity) {
                log(activity, "Resumed: ${activity.javaClass.simpleName}")
            }

            override fun onActivityPaused(activity: Activity) {}
            override fun onActivityStopped(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}
