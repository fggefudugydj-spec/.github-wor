package com.example.imported

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

data class ImportedApkInfo(
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val mainActivity: String,
    val themeResId: Int,
    val libName: String,
    val apkSizeBytes: Long,
    val importedAt: Long,
    val id: String = "",
    /** Non-empty when the APK stays in another folder (e.g. the LeviLab vault) instead of being copied. */
    val apkPath: String = ""
)

/**
 * Keeps a private, independent copy of a user-supplied Minecraft APK
 * (e.g. the Trial edition). It never touches any installed Minecraft app.
 */
object ImportedApkStore {

    const val EXPECTED_ACTIVITY = "com.mojang.minecraftpe.MainActivity"
    private const val ABI = "arm64-v8a"
    private const val MAIN_LIB_ENTRY = "lib/arm64-v8a/libminecraftpe.so"

    fun rootDir(context: Context): File = File(context.filesDir, "imported")
    fun versionsDir(context: Context): File = File(rootDir(context), "versions")
    private fun activeFile(context: Context): File = File(rootDir(context), "active.txt")
    fun runtimeLogFile(context: Context): File = File(rootDir(context), "mc_runtime.log")

    /** The id of the currently selected version (null when none). */
    fun activeId(context: Context): String? {
        return try {
            val f = activeFile(context)
            if (!f.exists()) return null
            val id = f.readText().trim()
            if (id.isNotEmpty() && File(versionsDir(context), id).isDirectory) id else null
        } catch (t: Throwable) {
            null
        }
    }

    fun setActive(context: Context, id: String) {
        rootDir(context).mkdirs()
        activeFile(context).writeText(id)
    }

    fun currentDir(context: Context): File = File(versionsDir(context), activeId(context) ?: "none")
    fun apkFile(context: Context): File {
        val external = readInfo(context)?.apkPath.orEmpty()
        return if (external.isNotEmpty()) File(external) else File(currentDir(context), "base.apk")
    }
    fun libDir(context: Context): File = File(currentDir(context), "lib/$ABI")

    private fun readInfoFromDir(dir: File): ImportedApkInfo? {
        return try {
            val f = File(dir, "info.json")
            if (!f.exists()) return null
            val j = JSONObject(f.readText())
            val external = j.optString("apkPath", "")
            val apkOk = if (external.isNotEmpty()) File(external).exists() else File(dir, "base.apk").exists()
            if (!apkOk) return null
            ImportedApkInfo(
                packageName = j.getString("packageName"),
                versionName = j.optString("versionName", "?"),
                versionCode = j.optLong("versionCode", 0L),
                mainActivity = j.getString("mainActivity"),
                themeResId = j.optInt("themeResId", 0),
                libName = j.optString("libName", "minecraftpe"),
                apkSizeBytes = j.optLong("apkSizeBytes", 0L),
                importedAt = j.optLong("importedAt", 0L),
                id = dir.name,
                apkPath = external
            )
        } catch (t: Throwable) {
            null
        }
    }

    /** Info of the active version. */
    fun readInfo(context: Context): ImportedApkInfo? {
        val id = activeId(context) ?: return null
        return readInfoFromDir(File(versionsDir(context), id))
    }

    /** All imported versions, newest first. */
    fun listVersions(context: Context): List<ImportedApkInfo> {
        val dirs = versionsDir(context).listFiles().orEmpty()
        return dirs.filter { it.isDirectory }
            .mapNotNull { readInfoFromDir(it) }
            .sortedByDescending { it.importedAt }
    }

    fun deleteVersion(context: Context, id: String) {
        File(versionsDir(context), id).deleteRecursively()
        if (activeId(context) == null) {
            val next = listVersions(context).firstOrNull()
            if (next != null) setActive(context, next.id) else activeFile(context).delete()
        }
    }

    private fun querySize(context: Context, uri: Uri): Long {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getLong(0) else -1L
            } ?: -1L
        }.getOrDefault(-1L)
    }

    fun importFromUri(
        context: Context,
        uri: Uri,
        onProgress: (String, Float) -> Unit
    ): Result<ImportedApkInfo> {
        val root = rootDir(context)
        root.mkdirs()
        val tmp = File(root, "tmp_${System.currentTimeMillis()}")
        return try {
            if (Build.SUPPORTED_64_BIT_ABIS.none { it == ABI }) {
                error("هذا الجهاز لا يدعم arm64-v8a")
            }
            tmp.mkdirs()
            val apk = File(tmp, "base.apk")
            val total = querySize(context, uri)
            if (total > 0 && tmp.usableSpace < total * 2 + 200L * 1024 * 1024) {
                error("المساحة غير كافية. تحتاج مساحة تقارب ضعف حجم الملف.")
            }

            // 1) Copy the APK into private storage
            onProgress("جاري نسخ الملف...", 0f)
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(apk).use { out ->
                    val buf = ByteArray(256 * 1024)
                    var copied = 0L
                    var lastReport = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        copied += n
                        if (total > 0 && copied - lastReport > 8L * 1024 * 1024) {
                            lastReport = copied
                            onProgress("جاري نسخ الملف...", (copied.toFloat() / total) * 0.5f)
                        }
                    }
                    out.flush()
                }
            } ?: error("تعذر فتح الملف المختار")

            // 2) Validate + extract native libs
            onProgress("جاري فحص الملف...", 0.5f)
            val libOut = File(tmp, "lib/$ABI")
            libOut.mkdirs()
            ZipFile(apk).use { zip ->
                if (zip.getEntry(MAIN_LIB_ENTRY) == null) {
                    val nested = zip.entries().asSequence().any { it.name.endsWith(".apk") }
                    if (nested) {
                        error("هذا الملف حزمة مجمّعة (xapk/apks). المطلوب ملف APK واحد.")
                    }
                    error("الملف لا يحتوي $MAIN_LIB_ENTRY. تأكد أنه APK نسخة ماين كرافت لمعالج 64 بت.")
                }
                val libEntries = zip.entries().asSequence()
                    .filter { !it.isDirectory && it.name.startsWith("lib/$ABI/") && it.name.endsWith(".so") }
                    .toList()
                libEntries.forEachIndexed { index, entry ->
                    val target = File(libOut, entry.name.substringAfterLast('/'))
                    zip.getInputStream(entry).use { ins ->
                        FileOutputStream(target).use { outS -> ins.copyTo(outS, 256 * 1024) }
                    }
                    onProgress(
                        "استخراج المكتبات (${index + 1}/${libEntries.size})",
                        0.5f + 0.4f * ((index + 1).toFloat() / libEntries.size)
                    )
                }
            }

            // 3) Read the manifest data of the APK
            onProgress("قراءة معلومات الحزمة...", 0.92f)
            @Suppress("DEPRECATION")
            val pi = context.packageManager.getPackageArchiveInfo(
                apk.absolutePath,
                PackageManager.GET_ACTIVITIES or PackageManager.GET_META_DATA
            ) ?: error("تعذر قراءة معلومات الحزمة (الملف تالف أو غير مدعوم)")

            val act = pi.activities.orEmpty().firstOrNull { it.name == EXPECTED_ACTIVITY }
                ?: error(
                    "لم أجد $EXPECTED_ACTIVITY. الأنشطة الموجودة: " +
                        pi.activities.orEmpty().joinToString { it.name }
                )
            val libName = act.metaData?.getString("android.app.lib_name") ?: "minecraftpe"

            val info = ImportedApkInfo(
                packageName = pi.packageName,
                versionName = pi.versionName ?: "?",
                versionCode = PackageInfoCompat.getLongVersionCode(pi),
                mainActivity = act.name,
                themeResId = act.theme,
                libName = libName,
                apkSizeBytes = apk.length(),
                importedAt = System.currentTimeMillis()
            )
            File(tmp, "info.json").writeText(
                JSONObject().apply {
                    put("packageName", info.packageName)
                    put("versionName", info.versionName)
                    put("versionCode", info.versionCode)
                    put("mainActivity", info.mainActivity)
                    put("themeResId", info.themeResId)
                    put("libName", info.libName)
                    put("apkSizeBytes", info.apkSizeBytes)
                    put("importedAt", info.importedAt)
                }.toString()
            )

            // Android 14+ refuses to load writable dex/apk files
            apk.setReadOnly()

            // 4) Replace the previous import
            onProgress("إنهاء الاستيراد...", 0.98f)
            val newId = "v${System.currentTimeMillis()}"
            versionsDir(context).mkdirs()
            val finalDir = File(versionsDir(context), newId)
            if (!tmp.renameTo(finalDir)) error("تعذر حفظ الملف النهائي")
            setActive(context, newId)
            onProgress("تم الاستيراد", 1f)
            Result.success(info.copy(id = newId))
        } catch (t: Throwable) {
            tmp.deleteRecursively()
            Result.failure(t)
        }
    }

    /**
     * Uses an APK that already sits in LeviLab's vault WITHOUT copying it again.
     * Only the native libraries are extracted (the game needs them as real files).
     * Re-uses an earlier registration of the same APK when it is still complete.
     */
    fun registerExisting(
        context: Context,
        source: File,
        onProgress: (String, Float) -> Unit
    ): Result<ImportedApkInfo> {
        val root = rootDir(context)
        root.mkdirs()
        val tmp = File(root, "tmp_${System.currentTimeMillis()}")
        return try {
            if (!source.isFile) error("ملف APK غير موجود: ${source.absolutePath}")
            val existing = listVersions(context).firstOrNull {
                it.apkPath == source.absolutePath &&
                    it.apkSizeBytes == source.length() &&
                    File(versionsDir(context), it.id + "/lib/$ABI/libminecraftpe.so").exists()
            }
            if (existing != null) {
                setActive(context, existing.id)
                onProgress("جاهز", 1f)
                return Result.success(existing)
            }
            if (Build.SUPPORTED_64_BIT_ABIS.none { it == ABI }) error("هذا الجهاز لا يدعم arm64-v8a")

            val libOut = File(tmp, "lib/$ABI")
            libOut.mkdirs()
            onProgress("فحص الملف...", 0.02f)
            ZipFile(source).use { zip ->
                if (zip.getEntry(MAIN_LIB_ENTRY) == null) {
                    error("الملف لا يحتوي $MAIN_LIB_ENTRY. المطلوب APK واحد لمعالج 64 بت.")
                }
                val libEntries = zip.entries().asSequence()
                    .filter { !it.isDirectory && it.name.startsWith("lib/$ABI/") && it.name.endsWith(".so") }
                    .toList()
                libEntries.forEachIndexed { index, entry ->
                    val target = File(libOut, entry.name.substringAfterLast('/'))
                    zip.getInputStream(entry).use { ins ->
                        FileOutputStream(target).use { outS -> ins.copyTo(outS, 256 * 1024) }
                    }
                    onProgress(
                        "استخراج المكتبات (${index + 1}/${libEntries.size})",
                        0.05f + 0.85f * ((index + 1).toFloat() / libEntries.size)
                    )
                }
            }

            onProgress("قراءة معلومات الحزمة...", 0.92f)
            @Suppress("DEPRECATION")
            val pi = context.packageManager.getPackageArchiveInfo(
                source.absolutePath,
                PackageManager.GET_ACTIVITIES or PackageManager.GET_META_DATA
            ) ?: error("تعذر قراءة معلومات الحزمة (الملف تالف أو غير مدعوم)")
            val act = pi.activities.orEmpty().firstOrNull { it.name == EXPECTED_ACTIVITY }
                ?: error("لم أجد $EXPECTED_ACTIVITY في الحزمة")
            val libName = act.metaData?.getString("android.app.lib_name") ?: "minecraftpe"

            val info = ImportedApkInfo(
                packageName = pi.packageName,
                versionName = pi.versionName ?: "?",
                versionCode = PackageInfoCompat.getLongVersionCode(pi),
                mainActivity = act.name,
                themeResId = act.theme,
                libName = libName,
                apkSizeBytes = source.length(),
                importedAt = System.currentTimeMillis(),
                apkPath = source.absolutePath
            )
            File(tmp, "info.json").writeText(
                JSONObject().apply {
                    put("packageName", info.packageName)
                    put("versionName", info.versionName)
                    put("versionCode", info.versionCode)
                    put("mainActivity", info.mainActivity)
                    put("themeResId", info.themeResId)
                    put("libName", info.libName)
                    put("apkSizeBytes", info.apkSizeBytes)
                    put("importedAt", info.importedAt)
                    put("apkPath", info.apkPath)
                }.toString()
            )
            source.setReadOnly() // Android 14+ refuses writable dex/apk files

            val staleIds = listVersions(context).filter { it.apkPath == source.absolutePath }.map { it.id }
            val newId = "v${System.currentTimeMillis()}"
            versionsDir(context).mkdirs()
            val finalDir = File(versionsDir(context), newId)
            if (!tmp.renameTo(finalDir)) error("تعذر حفظ الملف النهائي")
            setActive(context, newId)
            staleIds.forEach { File(versionsDir(context), it).deleteRecursively() }
            onProgress("تم التجهيز", 1f)
            Result.success(info.copy(id = newId))
        } catch (t: Throwable) {
            tmp.deleteRecursively()
            Result.failure(t)
        }
    }
}
