package com.example.engine

import android.content.Context
import com.example.model.ApkAssetsSummary
import com.example.model.AxmlManifestSummary
import com.example.model.CompatibilityIssue
import com.example.model.CompatibilityTier
import com.example.model.ElfInspectionResult
import com.example.model.InProcessCompatibilityReport
import com.example.model.InstalledMinecraftPackage
import java.io.File

object InProcessCompatAnalyzer {

    fun analyze(
        context: Context? = null,
        pkg: InstalledMinecraftPackage,
        libraries: List<ElfInspectionResult>,
        axml: AxmlManifestSummary?,
        dexFilesCount: Int,
        gameActivityDetected: Boolean,
        assetsSummary: ApkAssetsSummary?,
        apkPaths: List<String> = buildList {
            if (pkg.sourceDir.isNotBlank()) add(pkg.sourceDir)
            addAll(pkg.splitSourceDirs.filter { it.isNotBlank() })
        }
    ): InProcessCompatibilityReport {
        val dexSignals = runCatching {
            DexInspector.scanClassesByTerms(
                apkPaths = apkPaths,
                terms = listOf("pairip", "mcpelife", "InitializationProvider"),
                maxResults = 24
            )
        }.getOrDefault(emptyList())

        val appClass = axml?.applicationClassName?.takeIf { it.isNotBlank() }
        val providers = axml?.providers.orEmpty()

        val hasPairip = libraries.any { it.fileName.contains("pairip", ignoreCase = true) } ||
            (appClass?.contains("pairip", ignoreCase = true) == true) ||
            providers.any { it.name.contains("pairip", ignoreCase = true) } ||
            dexSignals.any { it.contains("pairip", ignoreCase = true) }

        val hasMcpelife = libraries.any { it.fileName.contains("mcpelife", ignoreCase = true) } ||
            dexSignals.any { it.contains("mcpelife", ignoreCase = true) }

        val hasArm64MainLib = libraries.any {
            it.fileName == "libminecraftpe.so" && it.isValid && it.isAArch64
        } || pkg.hasMainNativeLib

        val hasDex = dexFilesCount > 0 || !pkg.isVaultApk
        val hasAssets = (assetsSummary?.totalAssetFiles ?: 0) > 0
        val readableApks = apkPaths.filter { p -> File(p).let { it.isFile && it.canRead() } }
        val hasValidSplits = pkg.sourceDir.isNotBlank() && readableApks.size >= (1 + pkg.splitSourceDirs.size)

        val filesRoot = runCatching { context?.filesDir?.canonicalPath }.getOrNull()
        val isReadOnlyWxSafe = readableApks.all { path ->
            val f = File(path)
            val underFilesDir = filesRoot != null &&
                runCatching { f.canonicalPath.startsWith(filesRoot) }.getOrDefault(false)
            if (underFilesDir) !f.canWrite() else true
        }

        val issues = mutableListOf<CompatibilityIssue>()

        if (!hasArm64MainLib) {
            issues.add(
                CompatibilityIssue(
                    id = "missing_main_lib",
                    isBlocker = true,
                    titleAr = "مكتبة libminecraftpe.so (ARM64) مفقودة أو تالفة",
                    titleEn = "Valid ARM64 libminecraftpe.so Missing",
                    suggestionAr = "استورد الحزمة الكاملة (.apks/.xapk أو ملف config.arm64_v8a) أو اضغط «إصلاح بيئة التشغيل».",
                    suggestionEn = "Import the full split bundle (.apks/.xapk with arm64-v8a split) or run Repair Launch Env."
                )
            )
        }

        if (!hasDex) {
            issues.add(
                CompatibilityIssue(
                    id = "missing_dex",
                    isBlocker = true,
                    titleAr = "لم يتم العثور على شيفرة classes.dex قابلة للتحميل",
                    titleEn = "No Loadable classes.dex Found in APK",
                    suggestionAr = "تحقق من استيراد الملف الأساسي (base.apk) وليس ملف تقسيم الأصول أو المكتبات فقط.",
                    suggestionEn = "Verify you imported the base.apk alongside splits rather than an asset-only split."
                )
            )
        }

        if (!hasValidSplits) {
            issues.add(
                CompatibilityIssue(
                    id = "unreadable_splits",
                    isBlocker = true,
                    titleAr = "بعض ملفات Base/Split APK غير مقروءة",
                    titleEn = "Unreadable Base or Split APK File",
                    suggestionAr = "أعد استيراد ملف .apk/.apks إلى مخزن LeviLab.",
                    suggestionEn = "Re-import the .apk/.apks package into LeviLab Vault."
                )
            )
        }

        if (!isReadOnlyWxSafe) {
            issues.add(
                CompatibilityIssue(
                    id = "wx_writable_apk",
                    isBlocker = false,
                    titleAr = "ملف APK في المخزن قابل للكتابة (قاعدة W^X)",
                    titleEn = "Vault APK Is Writable (Android 14+ W^X Risk)",
                    suggestionAr = "اضغط «إصلاح بيئة التشغيل» لقفل الملف للقراءة فقط قبل تشغيل DexClassLoader.",
                    suggestionEn = "Tap Repair Launch Env to mark Vault APKs read-only for Android 14+ W^X compliance."
                )
            )
        }

        if (!hasAssets && apkPaths.isNotEmpty()) {
            issues.add(
                CompatibilityIssue(
                    id = "missing_assets",
                    isBlocker = false,
                    titleAr = "لم تُكتشف ملفات assets داخل الحزمة",
                    titleEn = "No APK Assets Detected",
                    suggestionAr = "تأكد من تضمين ملف الأصول في حزمة XAPK/APKS إذا كانت اللعبة مقسمة.",
                    suggestionEn = "Ensure install/asset splits were included if this package came from a split bundle."
                )
            )
        }

        if (hasPairip) {
            issues.add(
                CompatibilityIssue(
                    id = "pairip_detected",
                    isBlocker = false,
                    titleAr = "حماية Pairip نشطة (${appClass ?: "libpairipcore.so"})",
                    titleEn = "Pairip Protection Detected (${appClass ?: "libpairipcore.so"})",
                    suggestionAr = "فعّل «العزل الصارم لمخزن APK» و«تمهيد مزوّدات المحتوى». وإذا تعذّر التشغيل جرّب إيقاف Application المخصص وتنظيف DEX.",
                    suggestionEn = "Enable Strict Vault Isolation & Bootstrap Providers. If startup fails, try disabling Custom Application and cleaning DEX cache."
                )
            )
        }

        if (hasMcpelife) {
            issues.add(
                CompatibilityIssue(
                    id = "mcpelife_detected",
                    isBlocker = false,
                    titleAr = "طبقة libMCPELIFE.so / JNI مدمجة في الحزمة",
                    titleEn = "MCPELIFE Wrapper Layer Present",
                    suggestionAr = "قد يفحص MCPELIFE المسارات أو الحزمة المثبّتة على الهاتف؛ العزل الصارم يمنع تسرب /data/app/ إلى نفس العملية.",
                    suggestionEn = "MCPELIFE inspects package context and loaded maps; Strict Vault Isolation prevents /data/app/ leaks."
                )
            )
        }

        if (providers.isNotEmpty()) {
            val enabledCount = providers.count { it.enabled }
            issues.add(
                CompatibilityIssue(
                    id = "manifest_providers",
                    isBlocker = false,
                    titleAr = "يحتوي البيان على $enabledCount مزوّد محتوى (ContentProvider)",
                    titleEn = "Manifest Declares $enabledCount ContentProvider(s)",
                    suggestionAr = "سيقوم المحرك بتمهيدها عبر attachInfo قبل MainActivity.onCreate لتفادي سياق null.",
                    suggestionEn = "LeviLab will attach enabled ContentProviders before MainActivity.onCreate to prevent null init contexts."
                )
            )
        }

        val tier = when {
            issues.any { it.isBlocker } -> CompatibilityTier.BLOCKED
            hasPairip || hasMcpelife || !isReadOnlyWxSafe || !hasAssets -> CompatibilityTier.READY_WITH_MITIGATIONS
            else -> CompatibilityTier.READY_HIGH
        }

        return InProcessCompatibilityReport(
            hasPairip = hasPairip,
            hasMcpelife = hasMcpelife,
            hasGameActivity = gameActivityDetected,
            hasCustomApplication = !appClass.isNullOrBlank(),
            customApplicationClass = appClass,
            providerCount = providers.size,
            providers = providers,
            hasDex = hasDex,
            hasAssets = hasAssets,
            hasArm64MainLib = hasArm64MainLib,
            hasValidSplits = hasValidSplits,
            isReadOnlyWxSafe = isReadOnlyWxSafe,
            tier = tier,
            issues = issues
        )
    }
}
