package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.stringsFor
import com.example.imported.ImportedGameLauncherActivity
import com.example.model.LaunchMode
import com.example.model.LeviTab
import com.example.ui.screens.LaunchHealthScreen
import com.example.ui.screens.LogsScreen
import com.example.ui.screens.ProbeScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.theme.LeviLabTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeviApp(
    viewModel: LeviViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val strings = stringsFor(state.language)
    val context = LocalContext.current

    fun shareDiagnosticReport() {
        val report = viewModel.buildDiagnosticReportText()
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "LeviLab Diagnostic Report")
            putExtra(Intent.EXTRA_TEXT, report)
        }
        context.startActivity(Intent.createChooser(intent, strings.shareDiagnosticsLabel))
    }

    fun copyLogsToClipboard() {
        val text = viewModel.logger.readFullFileText()
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("LeviLab Logs", text))
        Toast.makeText(context, strings.copiedToast, Toast.LENGTH_SHORT).show()
    }

    fun startLaunchActivity(mode: LaunchMode) {
        // The in-process host is dead (MCPELIFE dex2c crashes there). Always use the
        // imported-APK screen, which runs the game in its own ":mc" process.
        val selected = state.selectedPackage
        val intent = Intent(context, ImportedGameLauncherActivity::class.java)
        if (selected?.isVaultApk == true) {
            // The APK picked on the main page is prepared and launched automatically.
            intent.putExtra(ImportedGameLauncherActivity.EXTRA_AUTO_APK, selected.sourceDir)
        }
        context.startActivity(intent)
    }

    LeviLabTheme(language = state.language) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            titleContentColor = MaterialTheme.colorScheme.onSurface
                        ),
                        title = {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = strings.appTitle,
                                    style = MaterialTheme.typography.titleLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = MaterialTheme.shapes.extraSmall
                                ) {
                                    Text(
                                        text = strings.targetVersionTag,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        },
                        actions = {
                            TextButton(
                                onClick = { viewModel.toggleLanguage() },
                                modifier = Modifier.testTag("toggle_language_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = strings.toggleLanguageLabel,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.size(4.dp))
                                Text(strings.toggleLanguageLabel)
                            }
                            IconButton(
                                onClick = {
                                    context.startActivity(
                                        Intent(context, ImportedGameLauncherActivity::class.java)
                                    )
                                },
                                modifier = Modifier.testTag("topbar_imported_game")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Run Minecraft from APK"
                                )
                            }
                            IconButton(
                                onClick = { shareDiagnosticReport() },
                                modifier = Modifier.testTag("topbar_share_diagnostics")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = strings.shareDiagnosticsLabel
                                )
                            }
                        }
                    )
                },
                bottomBar = {
                    if (!useRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            NavigationBarItem(
                                selected = state.currentTab == LeviTab.LAUNCH,
                                onClick = { viewModel.selectTab(LeviTab.LAUNCH) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.RocketLaunch,
                                        contentDescription = strings.tabLaunch
                                    )
                                },
                                label = { Text(strings.tabLaunch) },
                                modifier = Modifier.testTag("nav_launch")
                            )
                            NavigationBarItem(
                                selected = state.currentTab == LeviTab.PROBE,
                                onClick = { viewModel.selectTab(LeviTab.PROBE) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = strings.tabProbe
                                    )
                                },
                                label = { Text(strings.tabProbe) },
                                modifier = Modifier.testTag("nav_probe")
                            )
                            NavigationBarItem(
                                selected = state.currentTab == LeviTab.TOOLS,
                                onClick = { viewModel.selectTab(LeviTab.TOOLS) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Build,
                                        contentDescription = strings.tabTools
                                    )
                                },
                                label = { Text(strings.tabTools) },
                                modifier = Modifier.testTag("nav_tools")
                            )
                            NavigationBarItem(
                                selected = state.currentTab == LeviTab.LOGS,
                                onClick = { viewModel.selectTab(LeviTab.LOGS) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Terminal,
                                        contentDescription = strings.tabLogs
                                    )
                                },
                                label = { Text(strings.tabLogs) },
                                modifier = Modifier.testTag("nav_logs")
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            NavigationRailItem(
                                selected = state.currentTab == LeviTab.LAUNCH,
                                onClick = { viewModel.selectTab(LeviTab.LAUNCH) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.RocketLaunch,
                                        contentDescription = strings.tabLaunch
                                    )
                                },
                                label = { Text(strings.tabLaunch) },
                                modifier = Modifier.testTag("nav_launch")
                            )
                            NavigationRailItem(
                                selected = state.currentTab == LeviTab.PROBE,
                                onClick = { viewModel.selectTab(LeviTab.PROBE) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = strings.tabProbe
                                    )
                                },
                                label = { Text(strings.tabProbe) },
                                modifier = Modifier.testTag("nav_probe")
                            )
                            NavigationRailItem(
                                selected = state.currentTab == LeviTab.TOOLS,
                                onClick = { viewModel.selectTab(LeviTab.TOOLS) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Build,
                                        contentDescription = strings.tabTools
                                    )
                                },
                                label = { Text(strings.tabTools) },
                                modifier = Modifier.testTag("nav_tools")
                            )
                            NavigationRailItem(
                                selected = state.currentTab == LeviTab.LOGS,
                                onClick = { viewModel.selectTab(LeviTab.LOGS) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Terminal,
                                        contentDescription = strings.tabLogs
                                    )
                                },
                                label = { Text(strings.tabLogs) },
                                modifier = Modifier.testTag("nav_logs")
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        when (state.currentTab) {
                            LeviTab.LAUNCH -> LaunchHealthScreen(
                                state = state,
                                strings = strings,
                                onRescan = { viewModel.scanPackagesAndAutoProbe() },
                                onSelectPackage = { viewModel.selectPackageAndProbe(it) },
                                onLaunchVerified = {
                                    val effectiveMode = if (state.selectedPackage?.isVaultApk == true) {
                                        LaunchMode.DIRECT_NATIVE
                                    } else {
                                        state.preferredLaunchMode
                                    }
                                    startLaunchActivity(effectiveMode)
                                },
                                onLaunchQuickOfficial = { startLaunchActivity(LaunchMode.QUICK_OFFICIAL) },
                                onLaunchAdjacentSplit = { startLaunchActivity(LaunchMode.ADJACENT_SPLIT) },
                                onLaunchDirectSystem = { viewModel.launchInstalledDirectly(context) },
                                onRepairLibraries = { viewModel.repairLibraries() },
                                onClearCache = { viewModel.clearLibraryCache() },
                                onInspectExternalApk = { viewModel.inspectExternalApk(it) },
                                onImportApkToVault = { viewModel.importApkToVault(it) },
                                onRemoveVaultApk = { viewModel.removeVaultApk(it) },
                                onInstallExternalApk = { viewModel.openExternalApkInstaller(it, context) },
                                onDismissFailure = { viewModel.dismissLastFailure() },
                                onToggleKeepScreenOn = { viewModel.setKeepScreenOn(it) },
                                onToggleFloatingHud = { viewModel.setShowFloatingGameHud(it) },
                                onToggleLoadCustomMods = { viewModel.setLoadCustomNativeMods(it) },
                                onToggleAllowCustomApp = { viewModel.setAllowCustomApplication(it) },
                                onToggleBootstrapProviders = { viewModel.setBootstrapContentProviders(it) },
                                onToggleStrictVaultIsolation = { viewModel.setStrictVaultIsolation(it) },
                                onToggleImmersiveGame = { viewModel.setImmersiveGameSurface(it) },
                                onCleanDexCache = { viewModel.cleanDexCacheForSelected() },
                                onRepairLaunchEnv = { viewModel.repairLaunchEnvironmentForSelected() },
                                onRefreshStorage = { viewModel.refreshStorageBreakdown() }
                            )

                            LeviTab.PROBE -> ProbeScreen(
                                state = state,
                                strings = strings,
                                onSelectPackage = { viewModel.selectPackageAndProbe(it) },
                                onRunProbe = { viewModel.runProbeForSelected(forceReextract = false) },
                                onRepairCache = { viewModel.repairLibraries() },
                                onClearCache = { viewModel.clearLibraryCache() },
                                onCleanDexCache = { viewModel.cleanDexCacheForSelected() },
                                onRepairLaunchEnv = { viewModel.repairLaunchEnvironmentForSelected() }
                            )

                            LeviTab.TOOLS -> ToolsScreen(
                                state = state,
                                strings = strings,
                                onLoadOptionsTxt = { viewModel.onOptionsTxtPicked(it) },
                                onUpdateOptions = { viewModel.updateGraphicsOptions(it) },
                                onApplyPreset = { viewModel.applyGraphicsPreset(it) },
                                onSaveOptionsTxt = { viewModel.saveGraphicsOptionsToLoadedFile() },
                                onExportOptionsTxt = { viewModel.exportGraphicsOptionsToUri(it) },
                                onSelectPreferredLaunchMode = { viewModel.setPreferredLaunchMode(it) },
                                onToggleAutoVerifyCache = { viewModel.setAutoVerifyCache(it) },
                                onTogglePreferDirectApk = { viewModel.setPreferDirectApkLoad(it) },
                                onAddServer = { label, host, port ->
                                    viewModel.addServer(label, host, port)
                                },
                                onDeleteServer = { viewModel.deleteServer(it) },
                                onPingServer = { viewModel.pingServer(it) },
                                onPingAll = { viewModel.pingAllServers() },
                                onOpenServerInMinecraft = { viewModel.launchServerInMinecraft(it, context) },
                                onWorldFolderPicked = { viewModel.onWorldFolderPicked(it) },
                                onExportWorldDestPicked = { viewModel.onExportWorldDestinationPicked(it) },
                                onRestoreMcWorldPicked = { viewModel.onRestoreMcWorldPicked(it) },
                                onRestoreTargetFolderPicked = { viewModel.onRestoreWorldTargetFolderPicked(it) },
                                onConfirmRestoreOverwrite = { viewModel.confirmRestoreOverwrite() },
                                onCancelRestoreOverwrite = { viewModel.cancelRestoreOverwrite() },
                                onOpenRestoreWorldInMc = { viewModel.openSelectedRestoreWorldInMinecraft(context) },
                                onMcPackPicked = { viewModel.onMcPackPicked(it) },
                                onOpenSelectedPack = { viewModel.openSelectedPackInMinecraft(context) },
                                onSwitchFileBrowserMode = { viewModel.switchFileBrowserMode(it) },
                                onOpenSafFolderInFileManager = { viewModel.openSafFolderInFileManager(it) },
                                onFileEntryClick = { viewModel.onFileManagerEntryClick(it) },
                                onFileNavigateUp = { viewModel.navigateFileManagerUp() },
                                onCreateSafSubfolder = { viewModel.createSafSubfolder(it) },
                                onDeleteFileEntry = { viewModel.deleteFileManagerEntry(it) },
                                onDismissFilePreview = { viewModel.dismissFilePreview() },
                                onImportAddon = { viewModel.importAddonToVault(it) },
                                onToggleAddon = { viewModel.toggleAddonEnabled(it) },
                                onDeleteAddon = { viewModel.deleteAddon(it) },
                                onSyncAddonsToSandbox = { viewModel.syncAddonsToSandbox() },
                                onImportNativeMod = { viewModel.importNativeMod(it) },
                                onToggleNativeMod = { viewModel.toggleNativeModEnabled(it) },
                                onDeleteNativeMod = { viewModel.deleteNativeMod(it) },
                                onAddPopularServer = { viewModel.addPopularServerAndPing(it) }
                            )

                            LeviTab.LOGS -> LogsScreen(
                                state = state,
                                strings = strings,
                                onSelectSubTab = { viewModel.selectLogsSubTab(it) },
                                onSetFilter = { viewModel.setLogFilter(it) },
                                onCopyLogs = { copyLogsToClipboard() },
                                onShareDiagnosticReport = { shareDiagnosticReport() },
                                onClearLogs = { viewModel.clearLogs() },
                                onClearHistory = { viewModel.clearLaunchHistory() }
                            )
                        }
                    }
                }
            }
        }
    }
}
