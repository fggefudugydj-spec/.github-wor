package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.LeviStrings
import com.example.model.CompatibilityTier
import com.example.model.InProcessCompatibilityReport
import com.example.ui.theme.JetBrainsMonoFontFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InProcessCompatCard(
    report: InProcessCompatibilityReport,
    language: AppLanguage,
    strings: LeviStrings,
    hasSelectedPackage: Boolean,
    isRepairing: Boolean,
    isCleaningDexCache: Boolean,
    repairStatusMessage: String?,
    onRepairLaunchEnv: () -> Unit,
    onCleanDexCache: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tierColor = when (report.tier) {
        CompatibilityTier.READY_HIGH -> MaterialTheme.colorScheme.primary
        CompatibilityTier.READY_WITH_MITIGATIONS -> MaterialTheme.colorScheme.tertiary
        CompatibilityTier.BLOCKED -> MaterialTheme.colorScheme.error
    }
    val tierLabel = when (report.tier) {
        CompatibilityTier.READY_HIGH -> strings.compatTierHigh
        CompatibilityTier.READY_WITH_MITIGATIONS -> strings.compatTierMitigations
        CompatibilityTier.BLOCKED -> strings.compatTierBlocked
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, tierColor.copy(alpha = 0.6f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("in_process_compat_card")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = strings.compatAnalyzerTitle,
                        tint = tierColor
                    )
                    Text(
                        text = strings.compatAnalyzerTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.size(6.dp))
                Surface(
                    color = tierColor.copy(alpha = 0.16f),
                    shape = MaterialTheme.shapes.small,
                    border = BorderStroke(1.dp, tierColor.copy(alpha = 0.55f)),
                    modifier = Modifier.testTag("compat_tier_badge")
                ) {
                    Text(
                        text = tierLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = tierColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = strings.compatAnalyzerSubtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CompatPill(
                    label = if (report.hasPairip) "Pairip: Detected" else "Pairip: Clear",
                    positive = !report.hasPairip
                )
                CompatPill(
                    label = if (report.hasMcpelife) "MCPELIFE: Native Guard" else "MCPELIFE: Clear",
                    positive = !report.hasMcpelife
                )
                CompatPill(
                    label = if (report.hasGameActivity) "GameActivity: OK" else "GameActivity: ?",
                    positive = report.hasGameActivity
                )
                CompatPill(
                    label = "${strings.compatProvidersLabel}: ${report.providerCount}",
                    positive = true
                )
                CompatPill(
                    label = if (report.hasDex) "DEX: OK" else "DEX: Missing",
                    positive = report.hasDex
                )
                CompatPill(
                    label = if (report.hasAssets) "Assets: OK" else "Assets: Missing",
                    positive = report.hasAssets
                )
                CompatPill(
                    label = if (report.hasArm64MainLib) "ARM64: OK" else "ARM64: Missing",
                    positive = report.hasArm64MainLib
                )
                CompatPill(
                    label = if (report.isReadOnlyWxSafe) "W^X Read-Only: Safe" else "W^X: Needs Repair",
                    positive = report.isReadOnlyWxSafe
                )
            }

            report.customApplicationClass?.takeIf { it.isNotBlank() }?.let { appCls ->
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "${strings.compatCustomAppLabel}: $appCls",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFontFamily,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            if (report.issues.isEmpty()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = strings.compatNoIssuesLabel,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = strings.compatNoIssuesLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    report.issues.forEach { issue ->
                        val title = if (language == AppLanguage.AR) issue.titleAr else issue.titleEn
                        val suggestion = if (language == AppLanguage.AR) issue.suggestionAr else issue.suggestionEn
                        val issueColor = if (issue.isBlocker) {
                            MaterialTheme.colorScheme.error
                        } else {
                            MaterialTheme.colorScheme.tertiary
                        }
                        Surface(
                            color = issueColor.copy(alpha = 0.09f),
                            shape = MaterialTheme.shapes.small,
                            border = BorderStroke(1.dp, issueColor.copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = if (issue.isBlocker) Icons.Default.Error else Icons.Default.Warning,
                                    contentDescription = title,
                                    tint = issueColor,
                                    modifier = Modifier
                                        .padding(top = 2.dp)
                                        .size(16.dp)
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = suggestion,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onRepairLaunchEnv,
                    enabled = hasSelectedPackage && !isRepairing && !isCleaningDexCache,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("repair_launch_env_button")
                ) {
                    if (isRepairing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = strings.repairLaunchEnvButton,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        text = strings.repairLaunchEnvButton,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }

                OutlinedButton(
                    onClick = onCleanDexCache,
                    enabled = hasSelectedPackage && !isCleaningDexCache && !isRepairing,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("clean_dex_cache_button")
                ) {
                    if (isCleaningDexCache) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = strings.cleanDexCacheButton,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        text = if (isCleaningDexCache) strings.cleaningDexStatus else strings.cleanDexCacheButton,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }
            }

            repairStatusMessage?.takeIf { it.isNotBlank() }?.let { status ->
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("launch_repair_status_text")
                ) {
                    Text(
                        text = status,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFontFamily,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CompatPill(
    label: String,
    positive: Boolean
) {
    Surface(
        color = if (positive) {
            MaterialTheme.colorScheme.primaryContainer
        } else {
            MaterialTheme.colorScheme.tertiaryContainer
        },
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (positive) {
                MaterialTheme.colorScheme.onPrimaryContainer
            } else {
                MaterialTheme.colorScheme.onTertiaryContainer
            },
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
